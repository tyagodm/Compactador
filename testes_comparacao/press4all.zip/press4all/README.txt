
Para executar o press4all, no terminal, use o comando:
	java press4all